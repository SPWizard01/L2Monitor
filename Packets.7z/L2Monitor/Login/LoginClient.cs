﻿using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using PacketDotNet;
using PacketDotNet.Connections;
using L2Monitor.Common.Packets;
using L2Monitor.Util;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace L2Monitor.Login
{
    public class LoginClient
    {

        private static readonly byte[] STATIC_BLOWFISH_KEY = {
             0x6b,
             0x60,
             0xcb,
             0x5b,
             0x82,
             0xce,
             0x90,
             0xb1,
             0xcc,
             0x2b,
             0x6c,
             0x55,
             0x6c,
             0x6c,
             0x6c,
             0x6c
        };

        private BlowfishEngine STATIC_CRYPT = new BlowfishEngine();
        private BlowfishEngine _crypt = new BlowfishEngine();
        private KeyParameter _decryptKey;
        private bool _initial = true;

        public TcpConnection TcpConnection { get; set; }
        public int SessionId { get; set; }
        public byte[] RSAKey { get; set; }
        public byte[] BlowFishKey { get; set; }

        public LoginClient(TcpConnection connection)
        {
            TcpConnection = connection;
            KeyParameter staticKey = new KeyParameter(STATIC_BLOWFISH_KEY);
            STATIC_CRYPT.Init(false, staticKey);
            connection.OnPacketReceived += Connection_OnPacketReceived;
        }

        private void Connection_OnPacketReceived(SharpPcap.PosixTimeval timeval, TcpConnection connection, TcpFlow flow, TcpPacket tcp)
        {
            //incoming packets
            if (tcp.SourcePort == Constants.LOGIN_PORT && _initial)
            {
                TryInit(tcp);
                return;
            }

            // only after inited we can parse
            if (!_initial)
            {
                ParsePacket(tcp);
            }

        }

        public void ParsePacket(TcpPacket tcpPacket)
        {
            if (tcpPacket.PayloadData.Length == 0)
            {
                return;
            }
            var data = (byte[])tcpPacket.PayloadData.Clone();
            decrypt(data, Constants.HEADER_SIZE, data.Length - Constants.HEADER_SIZE);
            var pc = new OpCodePacket(new MemoryStream(data));
            Console.WriteLine((tcpPacket.DestinationPort == Constants.LOGIN_PORT ? "OUT: " : "IN:  ") + BitConverter.ToString(data));
        }

        public bool TryInit(TcpPacket tcpPacket)
        {
            if (tcpPacket.PayloadData.Length == 0)
            {
                return false;
            }
            try
            {
                var data = (byte[])tcpPacket.PayloadData.Clone();
                decrypt(data, Constants.HEADER_SIZE, data.Length - Constants.HEADER_SIZE);
                var pc = new OpCodePacket(new MemoryStream(data));
                if (!pc.OpCode.Match(LoginOpCodes.Init))
                {
                    return false;
                }
                //if it is init packet unxor it.
                decXORPass(data);


                var initPacket = new Init(new MemoryStream(data));

                SessionId = initPacket.SessionId;
                RSAKey = initPacket.RSAPublicKey;
                BlowFishKey = initPacket.BlowFishKey;
                _decryptKey = new KeyParameter(BlowFishKey);
                _crypt.Init(false, _decryptKey);

                Console.WriteLine($"Init SessionId: {SessionId}");
                Console.WriteLine($"Init RSAKey: {BitConverter.ToString(RSAKey)}");
                Console.WriteLine($"Init BlowFishKey: {BitConverter.ToString(BlowFishKey)}");
                Console.WriteLine("--");

                _initial = false;

            }
            catch (Exception e)
            {

                return false;
            }

            return true;
        }

        private void decrypt(byte[] raw, int offset, int size)
        {
            //BouncyCastle uses big endian for everything so we need to reverse
            if (BitConverter.IsLittleEndian)
            {
                for (int i = offset; i < (offset + size); i += 4)
                {
                    Array.Reverse(raw, i, 4);
                }
            }


            for (int i = offset; i < (offset + size); i += 8)
            {
                if (_initial)
                {
                    STATIC_CRYPT.ProcessBlock(raw, i, raw, i);
                }
                else
                {
                    _crypt.ProcessBlock(raw, i, raw, i);
                }

            }
            if (BitConverter.IsLittleEndian)
            {
                for (int i = offset; i < (offset + size); i += 4)
                {
                    Array.Reverse(raw, i, 4);
                }
            }
        }

        private static void decXORPass(byte[] raw)
        {
            //2 byte header
            //first 4 bytes are not xored

            int stop = 6;

            //last 4 bytes are empty after decryption so -4
            //4 bytes after that is initial key so another -4
            int pos = raw.Length - 8;
            int edx;
            // last key 
            int ecx = BitConverter.ToInt32(raw, pos);
            Array.Copy(BitConverter.GetBytes(0), 0, raw, pos, 4);
            pos -= 4;

            while (stop <= pos)
            {
                edx = BitConverter.ToInt32(raw, pos);

                edx ^= ecx;

                ecx -= edx;

                var edxBytes = BitConverter.GetBytes(edx);
                Array.Copy(edxBytes, 0, raw, pos, edxBytes.Length);
                pos -= 4;
            }
        }
    }
}
