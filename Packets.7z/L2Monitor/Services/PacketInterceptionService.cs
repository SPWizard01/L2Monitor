﻿using L2Monitor.Common;
using L2Monitor.Util;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using PacketDotNet;
using PacketDotNet.Connections;
using SharpPcap;
using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace L2Monitor.Services
{
    public class PacketInterceptionService: IHostedService
    {
        private TcpConnectionManager ConnectionManager;
        private ICaptureDevice CaptureDevice;
        //private ILogger
        public PacketInterceptionService(ILogger<PacketInterceptionService> logger)
        {
        }
        public void Run()
        {
            var ver = Pcap.Version;
            /* Print SharpPcap version */
            Console.WriteLine("SharpPcap {0}, Example6.DumpTCP.cs", ver);
            Console.WriteLine();

            
            /* Retrieve the device list */
            var devices = CaptureDeviceList.Instance;

            /*If no device exists, print error */
            if (devices.Count < 1)
            {
                Console.WriteLine("No device found on this machine");
                return;
            }

            Console.WriteLine("The following devices are available on this machine:");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine();

            int i = 0;

            /* Scan the list printing every entry */
            foreach (var dev in devices)
            {
                /* Description */
                Console.WriteLine("{0}) {1} {2}", i, dev.Name, dev.Description);
                i++;
            }

            Console.WriteLine();
            Console.Write("-- Please choose a device to capture: ");
            i = int.Parse(Console.ReadLine());

            CaptureDevice = devices[i];

            //Register our handler function to the 'packet arrival' event
            CaptureDevice.OnPacketArrival += device_OnPacketArrival;

            // Open the device for capturing
            int readTimeoutMilliseconds = 1000;
            CaptureDevice.Open(DeviceMode.Promiscuous, readTimeoutMilliseconds);
            ConnectionManager = new TcpConnectionManager();
            ConnectionManager.OnConnectionFound += TcpConnectionManager_OnConnectionFound; ;
            //tcpdump filter to capture only TCP/IP packets
            //host 109.105.133.76 and


            string filter = "host 109.105.133.76 and (tcp src port 2106 or " +
                                                     "tcp dst port 2106 or " +
                                                     "tcp src port 7777 or " +
                                                     "tcp dst port 7777)";
            CaptureDevice.Filter = filter;

            Console.WriteLine();
            //Console.WriteLine
            //    ("-- The following tcpdump filter will be applied: \"{0}\"",
            //    "filter");
            Console.WriteLine
                ("-- Listening on {0}, hit 'Ctrl-C' to exit...",
                CaptureDevice.Description);

            // Start capture 'INFINTE' number of packets
            CaptureDevice.Capture();
        }

        private void TcpConnectionManager_OnConnectionFound(TcpConnection connection)
        {
            //if(connection.Flows.Any(f=>f.port == Constants.LOGIN_PORT))
            //{
            //    ClientHandler.HandleLoginClient(connection);
            //}

            if (connection.Flows.Any(f => f.port == Constants.GAME_PORT))
            {
                ClientHandler.HandleGameClient(connection);
            }

        }


        private void device_OnPacketArrival(object sender, CaptureEventArgs e)
        {
            var packet = Packet.ParsePacket(e.Packet.LinkLayerType,
                                             e.Packet.Data);

            var tcpPacket = packet.Extract<TcpPacket>();
            var ipPacket = packet.Extract<IPPacket>();
            var ipv4Packet = packet.Extract<IPv4Packet>();
            // only pass tcp packets to the tcpConnectionManager
            if (tcpPacket?.SourcePort == Constants.LOGIN_PORT ||
                tcpPacket?.DestinationPort == Constants.LOGIN_PORT ||
                tcpPacket?.SourcePort == Constants.GAME_PORT ||
                tcpPacket?.DestinationPort == Constants.GAME_PORT)
            {
                ConnectionManager.ProcessPacket(e.Packet.Timeval, tcpPacket);
            }
        }
        
        

        public Task StartAsync(CancellationToken cancellationToken)
        {
            return Task.Run(Run);
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            ConnectionManager.OnConnectionFound -= TcpConnectionManager_OnConnectionFound;
            CaptureDevice.OnPacketArrival -= device_OnPacketArrival;
            CaptureDevice.StopCapture();
            CaptureDevice.Close();
            return Task.CompletedTask;
        }
    }
}
