﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L2Monitor.Util
{
    public class LoginOpCodes
    {
        public const byte Init = 0x00;
    }
}
